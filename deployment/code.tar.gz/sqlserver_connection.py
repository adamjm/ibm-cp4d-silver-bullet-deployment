from ibm_watson_studio_lib import access_project_or_space
wslib = access_project_or_space()
ODBC_MSSQL_Dallas_credentials = wslib.get_connection("ODBC_MSSQL_Dallas")

# print(ODBC_MSSQL_Dallas_credentials)

print('connecting ODBC_MSSQL_Dallas... ')


hostname = ODBC_MSSQL_Dallas_credentials['hostname']
port = ODBC_MSSQL_Dallas_credentials['port']
uname = ODBC_MSSQL_Dallas_credentials['username']
pwd = ODBC_MSSQL_Dallas_credentials['password']
dbname = ODBC_MSSQL_Dallas_credentials['database']


# Import necessary libraries
import pymssql, pandas as pd
from sqlalchemy import create_engine

# setup db connection with pymssql
db_con_pymssql = pymssql.connect(server='{}:{}'.format(hostname, port),
    user=uname,
    password=pwd,
    database=dbname)


# Create SQLAlchemy engine to connect to MySQL Database
engine = create_engine("mssql+pymssql://{user}:{pw}@{host}/{db}"
    .format(host=hostname, db=dbname, user=uname, pw=pwd))

# read table
src_tbl = 'TABLE010K'

print('src_tbl=', src_tbl)
# read table
query = 'SELECT * FROM '+ src_tbl
cursor = db_con_pymssql.cursor()
cursor.execute(query)
query_data = cursor.fetchall()

col_names = [colname[0] for colname in cursor.description]
data_df = pd.DataFrame(data=query_data, columns=col_names)
# data_df.head()

print(data_df.iloc[:3,:])


print('connecting Default_MSSQL_Dallas... ')

from ibm_watson_studio_lib import access_project_or_space
wslib = access_project_or_space()
Default_MSSQL_Dallas_credentials = wslib.get_connection("Default_MSSQL_Dallas")

import pymssql, pandas as pd
Default_MSSQL_Dallas_connection = pymssql.connect(server='{}:{}'.format(Default_MSSQL_Dallas_credentials['host'], Default_MSSQL_Dallas_credentials['port']),
    user=Default_MSSQL_Dallas_credentials['username'],
    password=Default_MSSQL_Dallas_credentials['password'],
    database=Default_MSSQL_Dallas_credentials['database'])

query = 'SELECT * FROM dbo.TABLE010K'
cursor = Default_MSSQL_Dallas_connection.cursor()
cursor.execute(query)
query_data = cursor.fetchall()

col_names = [colname[0] for colname in cursor.description]
data_df_1 = pd.DataFrame(data=query_data, columns=col_names)
print(data_df_1.iloc[3:6,:])