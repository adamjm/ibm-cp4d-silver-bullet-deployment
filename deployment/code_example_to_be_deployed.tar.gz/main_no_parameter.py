import os
import traceback
import warnings

warnings.filterwarnings("ignore")

import pandas as pd

print('Pandas version =', pd.__version__)
# print('seaborn version =', sns.__version__)

# This is a sample code
from utils.common_func import *

receivers = ['jbtang@au1.ibm.com', '', '']
wml_date_str = get_wml_date_str()

try:

    ############### Insert your main code ##################
    a = 1
    b = 4
    c = a + b
    print('sum is', c)

    from db_read.user_main import read_tss

    read_tss()

    import time

    # get the start time
    st = time.time()

    from datetime import datetime

    # Returns a datetime object containing the local date and time
    dateTimeObj = datetime.now()
    print(dateTimeObj)

    # main program
    # find sum to first 1 million numbers
    sum_x = 0
    for i in range(10000000):
        sum_x += i

    print('Sum of first 100 million numbers is:', sum_x)

    # get the end time
    et = time.time()

    # get the execution time
    elapsed_time = et - st
    print('Execution time:', elapsed_time, 'seconds')

    dur = datetime.now() - dateTimeObj
    print(dur)

    # get the start time
    st = time.time()
    # wait for 5 seconds
    time.sleep(1)
    # get the end time
    et = time.time()

    # get the execution time
    elapsed_time = et - st
    print('Execution time:', elapsed_time, 'seconds')
    dur = datetime.now() - dateTimeObj
    print(dur)

    ############### send successful notification ###############
    message = """Subject: {} Deployment Test has completed successfully
    Receipients: {}

    This message is sent from Cloud Pak for Data platform.

    ### Start of Message ###

    Deployment Test has completed successfully

    ### End of Message ###""".format(wml_date_str, receivers)

    send_email(receivers, message)

except Exception as e:
    print(e)
    # print(traceback.format_exc())

    ############### send email with error msg ##################
    message = """Subject: {} Error happened during Group Compliance Preprocessing - Wealth
    Receipients: {}

    This message is sent from Cloud Pak for Data platform.

    ### Start of Error Message ###

    {}

    {}

    ### End of Error Message ###""".format(wml_date_str, receivers, e, traceback.format_exc())

    send_email(receivers, message)